import pygame

pygame.joystick.init()
joysticks = [pygame.joystick.Joystick(x) for x in range(pygame.joystick.get_count())]

pygame.init()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            break
        if event.type == pygame.JOYAXISMOTION:
            print(event)
    x_speed = (pygame.joystick.Joystick(0).get_axis(0))
    y_speed = (pygame.joystick.Joystick(0).get_axis(1))
    r_speed = (pygame.joystick.Joystick(0).get_axis(2))
    v_speed = (pygame.joystick.Joystick(0).get_axis(3))
    # print("X-Speed " + str(x_speed) + "      Y-Speed " + str(y_speed) + "       R-Speed " + str(r_speed) + "       V-Speed " + str(v_speed))

    # Set thrusters to 100 or -100 value (only necessary for our equations)
    x_speed = x_speed*100
    y_speed = y_speed*100
    r_speed = r_speed*100
    v_speed = v_speed*100
    # print("X-Speed " + str(x_speed) + "      Y-Speed " + str(y_speed) + "       R-Speed " + str(r_speed) + "       V-Speed " + str(v_speed))
    print(r_speed)
    # Create thruster values
    T1 = 0
    T2 = 0
    T3 = 0
    T4 = 0
    T5 = 0
    T6 = 0

    # T1 Thruster
    if x_speed < 0:
        T1 = round((y_speed - (-1/750 * (-x_speed**2.5))) - r_speed)
    elif x_speed > 0:
        T1 = round((y_speed - (1/750 * (x_speed**2.5))) + r_speed)
    # T2 Thruster
    if x_speed < 0:
        T2 = round((-(y_speed-(-1/750 * (-x_speed**2.5)))) + r_speed)
    elif x_speed > 0:
        T2 = round((-(y_speed - (1/750 * (x_speed**2.5)))) - r_speed)
    # T3 Thruster
    if x_speed < 0:
        T3 = round((y_speed - (-1/750 * (-x_speed**2.5))) + r_speed)
    elif x_speed > 0:
        T3 = round((-(y_speed - (1/750 * (x_speed**2.5)))) - r_speed)
    # T4 Thruster
    if x_speed < 0:
        T4 = round((-(y_speed - (-1/750 * (-x_speed**2.5)))) + r_speed)
    elif x_speed > 0:
        T4 = round((-(y_speed - (1/750 * (x_speed**2.5)))) - r_speed)

    # T5 Thruster
    if v_speed < 0:
        T5 = round(1/1000 * (-v_speed**2.5))
    elif v_speed > 0:
        T5 = round(-1/1000 * (v_speed**2.5))
    # T6 Thruster
    if v_speed < 0:
        T6 = round(1/1000 * (-v_speed**2.5))
    elif v_speed > 0:
        T6 = round(-1/1000 * (v_speed**2.5))

    # Print each of the thruster final values
    #print("T1: " + str(T1) + "      T2: " + str(T2) + "     T3: " + str(T3) + "     T4: " + str(T4) + "     T5: " + str(T5) + "     T6: " + str(T6))

# TO DO
# Need to solve range issues with formula --> isn't a smooth exponential output, only outputs 33, 133, 233, 0) -- fixed??
    # now outputs a constant range, but randomly sets all the values to 0?? (FINISHED)
# Add in T5, T6 (FINISHED)
# Figure out how to convert equation values into a power output (reference one thruster code)
