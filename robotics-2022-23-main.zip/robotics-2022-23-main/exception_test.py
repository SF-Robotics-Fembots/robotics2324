# EXCEPTION TEST 

import lgpio
import pygame
import board
import busio
import adafruit_pca9685
from adafruit_servokit import ServoKit
import time
import socket

# library setup
pygame.init()

i2c = busio.I2C(board.SCL, board.SDA)
shield = adafruit_pca9685.PCA9685(i2c)
kit = ServoKit(channels=16)
shield.frequency = 100
    
thrusterChannel1 = shield.channels[0]
thrusterChannel2 = shield.channels[1]
thrusterChannel3 = shield.channels[2]
thrusterChannel4 = shield.channels[3]
thrusterChannel5 = shield.channels[4]
thrusterChannel6 = shield.channels[5]
thrusterChannel1.duty_cycle = 0x2666
    
throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel1.duty_cycle = throttlePW
time.sleep(0)
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel1.duty_cycle = throttlePW
time.sleep(0)

throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel2.duty_cycle = throttlePW
time.sleep(0)
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel2.duty_cycle = throttlePW
time.sleep(0)

throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel3.duty_cycle = throttlePW
time.sleep(0 )
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel3.duty_cycle = throttlePW
time.sleep(0)

throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel4.duty_cycle = throttlePW
time.sleep(0)
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel4.duty_cycle = throttlePW
time.sleep(0)

throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel5.duty_cycle = throttlePW
time.sleep(0)
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel5.duty_cycle = throttlePW
time.sleep(0)

throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel6.duty_cycle = throttlePW
time.sleep(0)
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel6.duty_cycle = throttlePW
time.sleep(0)

# horizontal thrusters calculations
def calcHorizontal(joyValue, thrusterNum, direction):
    if (-5 <= joyValue <= 5):         # can adjust to create deadzone
        return 0
    # calculation for everything but 0
    else:
        joyValue = joyValue - ((abs(joyValue)/joyValue) * 5)
        return joyValue * direction[thrusterNum]
        #return (((1/750) * ((abs(joyValue))**2.5)) * ((abs(joyValue))/(joyValue)) * direction[thrusterNum])

# vertical thrusters calculations
def calcVertical(joyValue, thrusterNum, direction):
    if (-5 <= joyValue <= 5):
        return 0
    # calculation for everything not 0
    else:
        joyValue + ((abs(joyValue)/joyValue) * 5)
        return (((1/1000) * ((abs(joyValue))**2.5)) * ((abs(joyValue))/(joyValue)) * direction[thrusterNum]) #was 1000

clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientSocket.connect(("192.168.1.100", 9090))

prevX = 0
prevY = 0
prevV = 0
prevR = 0

# main loop
while True:
    try:
    	#for event in pygame.event.get():
         #   if event.type == pygame.QUIT:
          #      break
           # if event.type == pygame.JOYAXISMOTION:
            #    print(event)
    
    	dataFraud = (clientSocket.recv(1024)).decode()
    	#print("datafraud: " + dataFraud)
    	data = (clientSocket.recv(1024)).decode()
    
    	#print("data " + data)
    
    	x_speed = dataFraud
    	x_speed = x_speed[1:]
    	x_speed = float(x_speed)
    	#print(type(x_speed))
    	#print(x_speed)
    	
    	y_speed = data[data.find('y'):data.find('r')]
    	y_speed = y_speed[1:]
    	y_speed = float(y_speed)
    	#print(type(y_speed))
    	#print(y_speed)
    
    	r_speed = data[data.find('r'):data.find('v')]
    	r_speed = r_speed[1:]
    	r_speed = float(r_speed)
    	#print(type(r_speed))
    	#print(r_speed)
    	v_speed = data[data.find('v'):data.find('x')]
    	v_speed = v_speed[1:]
    	v_speed = float(v_speed)
    	#print(type(v_speed))
    	#print(v_speed
    	 	
    	diffX = x_speed - prevX
    	diffY = y_speed - prevY
    	diffR = r_speed - prevR
    	diffV = v_speed - prevV
    	
    	if (abs(diffX) > 0.05):
    	    x_speed = prevX + ((diffX/abs(diffX)) * 0.10)
    	if (abs(diffY) > 0.05):
    	    y_speed = prevY + ((diffY/abs(diffY)) * 0.10)
    	if (abs(diffR) > 0.05):
    	    r_speed = prevR + ((diffR/abs(diffR)) * 0.10)
    	if (abs(diffV) > 0.05):
    	    v_speed = prevV + ((diffV/abs(diffV)) * 0.10)
    	    
    	prevX = x_speed
    	prevY = y_speed
    	prevR = r_speed
    	prevV = v_speed
    	
    	# multiplies original values by 100 (necessary for calculations)
    	x_speed = int((x_speed)*50)
    	y_speed = int((y_speed)*50)
    	r_speed = int((r_speed)*50)
    	v_speed = int((v_speed)*50)
    	
    	#print(x_speed)
    	#print(y_speed)
    	#print(r_speed)
    	#print(v_speed)
    	
    	# print("X-Speed " + str(x_speed) + "      Y-Speed " + str(y_speed) + "       R-Speed " + str(r_speed) + "       V-Speed " + str(v_speed))
	    #print(r_speed)

    	# each item in the list represents if the output for each thruster is pos. or neg.
    	# ex: in xDirArray, the first element in index 0 (-1) expects that T1 would have a neg. output given a direction
    	# WORKING DIRECTIONS
    	xDirArray = [-1, 1, -1, 1]
    	yDirArray = [1, 1, -1, -1]
    	rDirArray = [-1, 1, 1, -1]
    	vDirArray = [-1, -1]
	
    	# array for each horizontal thruster value
    	thrusterVals = [0, 0, 0, 0]
    	# array for each vertical thruster value
    	vertThrusterVals = [0, 0]
	
    	# loop to collect value for each thruster using horizontal calculation function
    	for tNum in range(0,4):
    	    thrusterVals[tNum] = int((calcHorizontal(x_speed, tNum, xDirArray) + calcHorizontal(y_speed, tNum, yDirArray) + calcHorizontal(r_speed, tNum, rDirArray)))
		#print(thrusterVals[tNum])	
    	# loop to collect value for each thruster using vertical calculation function
    	for vNum in range(0,2):
    	    vertThrusterVals[vNum] = int((calcVertical(v_speed, vNum, vDirArray)))
	
    	print("first print")
    	print(thrusterVals)
	
	# original print
	
    	# adjusting range
    	max_thruster = 0
    	for thrusters in range(0,4):
    	    max_thruster = max(max_thruster, abs(thrusterVals[thrusters]))
	    #print(max_thruster)
	
    	if (max_thruster != 0) and (max_thruster >= 50):
    	    for thrusters in range(0, 4):
    	        thrusterVals[thrusters] = int(thrusterVals[thrusters] * (50 / max_thruster))
    	
    	print("second print")
    	print(thrusterVals)
    	
    	# new lists for the adjusted values for our power functions
    	powerThrusterVals = [0, 0, 0, 0]
    	powerVertThrusterVals = [0, 0]

    	# both for loops adjust the range of the thrusters to 1000-2000
    	for thrusters in range(0, 4):
    	    if (thrusterVals[thrusters] == 0):
    	        powerThrusterVals[thrusters] = 1489
    	    else:
                #powerThrusterVals[thrusters] = 1489 + (((abs(thrusterVals[thrusters]))/thrusterVals[thrusters]) * (25 + (thrusterVals[thrusters] * 4.64)))
                powerThrusterVals[thrusters] = 1489 + ((abs(thrusterVals[thrusters])/thrusterVals[thrusters]) * 25) + (thrusterVals[thrusters] * 4.64)
	    #print(powerThrusterVals)
	    #was 25 and 4.64
    	# NOTE - when going full down, the lowest the value goes is 1015 -- fix later --
    	for vertThrusters in range(0, 2):
    	    if (vertThrusterVals[vertThrusters] == 0):
    	        powerVertThrusterVals[vertThrusters] = 1489
    	    else:
    	        #powerVertThrusterVals[vertThrusters] = 1489 + (((abs(vertThrusterVals[vertThrusters]))/vertThrusterVals[vertThrusters]) * (25 + (vertThrusterVals[vertThrusters] * 4.64)))
    	        powerVertThrusterVals[vertThrusters] = 1489 + ((abs(vertThrusterVals[vertThrusters])/vertThrusterVals[vertThrusters]) * 5) + ((abs(vertThrusterVals[vertThrusters])/vertThrusterVals[vertThrusters]) * ((abs(vertThrusterVals[vertThrusters])/vertThrusterVals[vertThrusters]) * vertThrusterVals[vertThrusters]) * 4.64)
	
    	
    	
	 # other print
    	#print(max_thruster)
    	# PRINT
    	    
    	# Set-up --- Should check if set up correctly
    	#print(powerThrusterVals[1])
    	
    	
    	
    	finalHorDiff = abs(powerThrusterVals[1] - 1489)
    	finalVertDiff = abs(powerVertThrusterVals[1] - 1489)
    	finalTotal = (finalHorDiff * 4) + (finalVertDiff * 2)
    	if (finalTotal != 0):
    	    percent = (1500/finalTotal)
    	    if (finalTotal > 1500): #max is 2934
    	        for thruster in range(0, 4):
    	            Diff = powerThrusterVals[thruster] - 1489
    	            newDiff = Diff * (percent)
    	            powerThrusterVals[thruster] = 1489 + newDiff
    	        for vertThruster in range(0, 2):
    	            vertDiff = powerVertThrusterVals[vertThruster] - 1489
    	            newVertDiff = vertDiff * (percent)
    	            powerVertThrusterVals[vertThruster] = 1489 + newVertDiff
    	        
    	print("third print")
    	print(powerThrusterVals)
    	print(powerVertThrusterVals)
    	
    	throttlePW = int(powerThrusterVals[0]/10000*65536)
    	thrusterChannel1.duty_cycle = throttlePW
    	
    	throttlePW = int(powerThrusterVals[1]/10000*65536)
    	thrusterChannel2.duty_cycle = throttlePW
    	
    	throttlePW = int(powerThrusterVals[2]/10000*65536)
    	thrusterChannel3.duty_cycle = throttlePW
    	
    	throttlePW = int(powerThrusterVals[3]/10000*65536)
    	thrusterChannel4.duty_cycle = throttlePW
    	
    	throttlePW = int(powerVertThrusterVals[0]/10000*65536)
    	thrusterChannel5.duty_cycle = throttlePW
    	
    	throttlePW = int(powerVertThrusterVals[1]/10000*65536)
    	thrusterChannel6.duty_cycle = throttlePW
#    	time.sleep(1)
    	
    except ValueError:
    	print("Error")
    	check = (clientSocket.recv(1024)).decode()
    	print("check: " + check)
    	
