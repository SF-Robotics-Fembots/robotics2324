import socket

clientSocket1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientSocket1.connect(("192.168.1.100", 5000))

clientSocket2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientSocket2.connect(("192.168.1.100", 9090))

while True:
    hatVal = int((clientSocket1.recv(1024)).decode())
    print(hatVal)
    data = float((clientSocket2.recv(1024)).decode())
    print(data)
