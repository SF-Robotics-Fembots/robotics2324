import socket
import pwmio
import RPi.GPIO as GPIO
import time
from adafruit_motor import servo
def main(ip_server):
    servoPin = 17
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(servoPin, GPIO.OUT)
    pwm = GPIO.PWM(servoPin, 50)
    pwm.start(0)
    clientSocket1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# 192.168.1.100 is comp computer ip
    clientSocket1.connect((ip_server, 5000))
    var = 7
    while True:
        hatVal = ((clientSocket1.recv(1)).decode())
        #print(hatVal)
        if (hatVal == "a"):
            var += 1
            if (0 <= var <= 100):
                pwm.ChangeDutyCycle(var)
                time.sleep(.25)
                pwm.ChangeDutyCycle(0)
        elif(hatVal == "b"):
            var -= 1
            if (0 <= var <= 100):
                pwm.ChangeDutyCycle(var)
                time.sleep(.25)
                pwm.ChangeDutyCycle(0)
        if (var > 12):
            var = 12
        if (var < 2):
            var = 2
        #print(var)
    GPIO.cleanup()

if __name__ == "__main__":
    main()
