import RPi.GPIO as GPIO
import time
import socket


def main(ip_server): 
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    GPIO.setup(27, GPIO.OUT)

    clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# 192.168.1.100 is comp computer ip
    clientSocket.connect((ip_server, 8080))

    while True:
        button = ((clientSocket.recv(1)).decode())
        #print(button)
        if (button == "a"):
            GPIO.output(27, GPIO.HIGH)
        if (button == "b"):
            GPIO.output(27, GPIO.LOW)

if __name__ == "__main__":
    main()
