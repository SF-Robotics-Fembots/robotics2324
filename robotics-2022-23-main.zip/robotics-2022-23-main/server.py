import socket

serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serverSocket.bind(('192.168.1.103', 5050))
serverSocket.listen(0)
print("socket listening")

conn, addr = serverSocket.accept()
print("socket accepted")

with conn:
    print("connected")
    while True:
        data = conn.recv(1024)
        if not data:
                break
        conn.sendall(data)
