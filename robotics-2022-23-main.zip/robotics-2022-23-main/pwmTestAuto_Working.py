import lgpio
import time
from adafruit_servokit import ServoKit
import board
import busio
import adafruit_pca9685

i2c = busio.I2C(board.SCL, board.SDA)
shield = adafruit_pca9685.PCA9685(i2c)
kit = ServoKit(channels = 16)
shield.frequency = 100
thruster_channel = shield.channels[0]
thruster_channel.duty_cycle = 0x2666

throttle_in = 2200
throttle_pw = int(throttle_in/10000*65536)
thruster_channel.duty_cycle = throttle_pw
time.sleep(5)
throttle_in = 1480
throttle_pw = int(throttle_in/10000*65536)
thruster_channel.duty_cycle = throttle_pw
time.sleep(5)

try:
	while 1:
		throttle_in = 2000
		throttle_pw = int(throttle_in/10000*65536)
		#print(throttle_pw)
		thruster_channel.duty_cycle = throttle_pw
		time.sleep(5)
		throttle_in = 1000
		throttle_pw = int(throttle_in/10000*65536)
		#print(throttle_pw)
		thruster_channel.duty_cycle = throttle_pw
		time.sleep(5)
		throttle_in = 1750
		throttle_pw = int(throttle_in/10000*65536)
		#print(throttle_pw)
		thruster_channel.duty_cycle = throttle_pw
		
except KeyboardInterrupt:
	throttle_in = 1480
	throttle_pw = int(throttle_in/10000*65536)
	thruster_channel.duty_cycle = throttle_pw
	time.sleep(5)
