import pygame

pygame.joystick.init()
joysticks = [pygame.joystick.Joystick(x) for x in range(pygame.joystick.get_count())]

pygame.init()

# horizontal thrusters calculations
def calcFunction(joyValue, thrusterNum, direction):
    if (joyValue == 0):
        return 0
    return (((1/750) * ((abs(joyValue))**2.5)) * ((abs(joyValue))/(joyValue)) * direction[thrusterNum])

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            break
        if event.type == pygame.JOYAXISMOTION:
            print(event)
    x_speed = (pygame.joystick.Joystick(0).get_axis(0))
    y_speed = (pygame.joystick.Joystick(0).get_axis(1))
    r_speed = (pygame.joystick.Joystick(0).get_axis(2))
    v_speed = (pygame.joystick.Joystick(0).get_axis(3))
    #print("X-Speed " + str(x_speed) + "      Y-Speed " + str(y_speed) + "       R-Speed " + str(r_speed) + "       V-Speed " + str(v_speed))

    # adjusting rotation range
    r_speed += 0.5
    if r_speed < 0:
        r_speed = r_speed * 2
    #print(r_speed)

    x_speed = int(x_speed*100)
    y_speed = int(y_speed*100)
    r_speed = int(r_speed*50)
    v_speed = int(v_speed*100)
    # print("X-Speed " + str(x_speed) + "      Y-Speed " + str(y_speed) + "       R-Speed " + str(r_speed) + "       V-Speed " + str(v_speed))
    #print(r_speed)

    xDirArray = [-1, -1, 1, 1]
    yDirArray = [1, -1, 1, -1]
    thrusterVals = [0, 0, 0, 0]

    for thrusterNum in range(0,4):
        thrusterVals[thrusterNum] = calcFunction(x_speed, thrusterNum, xDirArray) + calcFunction(y_speed, thrusterNum, yDirArray)

    print(thrusterVals[0], " - ", thrusterVals[1], " - " , thrusterVals[2], " - ", thrusterVals[3])

    #print("T1: " + str(T1) + "       T2: " + str(T2) + "        T3: " + str(T3) + "        T4: " + str(T4))
    #print("T1: " + str(T1) + "    T2: " + str(T2))


# >= 0 for one of conditionals
# need to have conditionals for x & y
    # T1 good, T2 not good