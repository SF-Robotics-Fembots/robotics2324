import lgpio
import pygame
import board
import busio
import adafruit_pca9685
from adafruit_servokit import ServoKit
import time
import socket

if (piInversion == True):
    
