print("Beginning")

import lgpio
import pygame
import board
import busio
import adafruit_pca9685
from adafruit_servokit import ServoKit
import time

print("Starting program")

# library setup
pygame.joystick.init()
joysticks = [pygame.joystick.Joystick(x) for x in range(pygame.joystick.get_count())]

pygame.init()

i2c = busio.I2C(board.SCL, board.SDA)
shield = adafruit_pca9685.PCA9685(i2c)
kit = ServoKit(channels=16)
shield.frequency = 100
    
thrusterChannel1 = shield.channels[0]
thrusterChannel2 = shield.channels[1]
thrusterChannel3 = shield.channels[2]
thrusterChannel4 = shield.channels[3]
thrusterChannel5 = shield.channels[4]
thrusterChannel6 = shield.channels[5]
thrusterChannel1.duty_cycle = 0x2666

# Initialization process --> go full speed, then neutral zone

throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel1.duty_cycle = throttlePW
time.sleep(0)
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel1.duty_cycle = throttlePW
time.sleep(0)

throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel2.duty_cycle = throttlePW
time.sleep(0)
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel2.duty_cycle = throttlePW
time.sleep(0)

throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel3.duty_cycle = throttlePW
time.sleep(0)
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel3.duty_cycle = throttlePW
time.sleep(0)

throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel4.duty_cycle = throttlePW
time.sleep(0)
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel4.duty_cycle = throttlePW
time.sleep(0)

throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel5.duty_cycle = throttlePW
time.sleep(0)
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel5.duty_cycle = throttlePW
time.sleep(0)

throttle_in = 2200
throttlePW = int(throttle_in/10000*65536)
thrusterChannel6.duty_cycle = throttlePW
time.sleep(0)
    
throttle_in = 1480
throttlePW = int(throttle_in/10000*65536)
thrusterChannel6.duty_cycle = throttlePW
time.sleep(0)

# horizontal thrusters calculations
def calcHorizontal(joyValue, thrusterNum, direction):
    #if (-20 <= joyValue <= 20):
    if (joyValue == 0):         # can adjust to create deadzone
        return 0
    # calculation for everything but 0
    return (((1/750) * ((abs(joyValue))**2.5)) * ((abs(joyValue))/(joyValue)) * direction[thrusterNum])
    
# vertical thrusters calculations
def calcVertical(joyValue, thrusterNum, direction):
    if (joyValue == 0):
        return 0
    # calculation for everything not 0
    return (((1/1000) * ((abs(joyValue))**2.5)) * ((abs(joyValue))/(joyValue)) * direction[thrusterNum])

# main loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            break
        #if event.type == pygame.JOYAXISMOTION:
            #print(event)
    # collect joystick values as -1 to 1
    x_speed = (pygame.joystick.Joystick(0).get_axis(0))
    y_speed = (pygame.joystick.Joystick(0).get_axis(1))
    r_speed = (pygame.joystick.Joystick(0).get_axis(2))
    v_speed = (pygame.joystick.Joystick(0).get_axis(3))
    #print("X-Speed " + str(x_speed) + "      Y-Speed " + str(y_speed) + "       R-Speed " + str(r_speed) + "       V-Speed " + str(v_speed))

    # ONLY USE IF ROTATION RANGE IS OFF
    # adjusting rotation range
    #r_speed += 0.5
    #if r_speed < 0:
        #r_speed = r_speed * 2
    #print(r_speed)

    # multiplies original values by 100 (necessary for calculations)
    x_speed = int(x_speed*100)
    y_speed = int(y_speed*100)
    #r_speed = int(r_speed*100)
    r_speed = 0
    v_speed = int(v_speed*100)
    # print("X-Speed " + str(x_speed) + "      Y-Speed " + str(y_speed) + "       R-Speed " + str(r_speed) + "       V-Speed " + str(v_speed))
    #print(r_speed)

    # each item in the list represents if the output for each thruster is pos. or neg.
    # ex: in xDirArray, the first element in index 0 (-1) expects that T1 would have a neg. output given a direction
    #xDirArray = [-1, -1, 1, 1]
    #yDirArray = [1, -1, 1, -1]
    #rDirArray = [-1, 1, 1, -1]
    #vDirArray = [-1, -1]
    
    # WORKING DIRECTIONS
    xDirArray = [-1, 1, -1, 1]
    yDirArray = [1, 1, -1, -1]
    rDirArray = [-1, 1, 1,  -1]
    vDirArray = [-1, -1]
    # array for each horizontal thruster value
    thrusterVals = [0, 0, 0, 0]
    # array for each vertical thruster value
    vertThrusterVals = [0, 0]

    # loop to collect value for each thruster using horizontal calculation function
    for tNum in range(0,4):
        thrusterVals[tNum] = int((calcHorizontal(x_speed, tNum, xDirArray) + calcHorizontal(y_speed, tNum, yDirArray) + calcHorizontal(r_speed, tNum, rDirArray)))
    #print(thrusterVals[1])
    #print(thrusterVals[0])
        #print(thrusterVals[tNum])
    # loop to collect value for each thruster using vertical calculation function
    for vNum in range(0,2):
        vertThrusterVals[vNum] = int((calcVertical(v_speed, vNum, vDirArray)))

    # adjusting range
    max_thruster = 0
    for thrusters in range(0,4):
        max_thruster = max(max_thruster, abs(thrusterVals[thrusters]))
        #print(max_thruster)

    if (max_thruster != 0) and (max_thruster >= 100):
        for thrusters in range(0, 4):
            thrusterVals[thrusters] = int(thrusterVals[thrusters] * (100 / max_thruster))
	
    # new lists for the adjusted values for our power functions
    powerThrusterVals = [0, 0, 0, 0]
    powerVertThrusterVals = [0, 0]

    # both for loops adjust the range of the thrusters to 1000-2000
    for thrusters in range(0, 4):
        powerThrusterVals[thrusters] = (5 * thrusterVals[thrusters]) + 1500

    # NOTE - when going full down, the lowest the value goes is 1015 -- fix later --
    for vertThrusters in range(0, 2):
        powerVertThrusterVals[vertThrusters] = (5 * vertThrusterVals[vertThrusters]) + 1500

    #print(max_thruster)
    # PRINT

    # Set-up --- Should check if set up correctly
    #print(powerThrusterVals[1])
    
    throttlePW = int(powerThrusterVals[0]/10000*65536)
    thrusterChannel1.duty_cycle = throttlePW
    
    throttlePW = int(powerThrusterVals[1]/10000*65536)
    thrusterChannel2.duty_cycle = throttlePW
    
    throttlePW = int(powerThrusterVals[2]/10000*65536)
    thrusterChannel3.duty_cycle = throttlePW
    
    throttlePW = int(powerThrusterVals[3]/10000*65536)
    thrusterChannel4.duty_cycle = throttlePW
    
    throttlePW = int(powerVertThrusterVals[0]/10000*65536)
    thrusterChannel5.duty_cycle = throttlePW
    
    throttlePW = int(powerVertThrusterVals[1]/10000*65536)
    thrusterChannel6.duty_cycle = throttlePW
    
    print(thrusterVals)
    print(powerThrusterVals)
    if (abs(powerThrusterVals[0] - powerThrusterVals[1]) > 15):
        print("ERROR ----------------------------------")
    
    #thruster_channels = shield.channels[0, 1, 2, 3, 4, 5]   # can a list be used here
    #thruster_channels.duty_cycle = 0x2666   # how did we get this value // is this value correct

    #throttlePW = [0, 0, 0, 0]   # List to store horizontal thrusters' pwm values
    #vertThrottlePW = [0, 0]    # List to store vertical thrusters' pwm values

    # Each horizontal thruster power value (1000-2000) undergoes this calculation and put into a new list
    #for x in range(0,4):
     #   throttlePW = int(powerThrusterVals[x] / 10000 * 65536)

    # Each vertical thruster power value (1000-2000) undergoes this calculation and put into a new list
    #for x in range(0,2):
     #   vertThrottlePW = int(powerVertThrusterVals[x] / 10000 * 65536)

    # This sends power to the horizontal thrusters
   # for x in range(0,4):
    #    thruster_channels[x].duty_cycle = throttlePW[x]

    # This sends power to the vertical thrusters
    #for x in range(0,2):
     #   thruster_channels[x + 4].duty_cycle = vertThrottlePW[x]
