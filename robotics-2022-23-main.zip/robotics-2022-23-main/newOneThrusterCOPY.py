import pygame

pygame.joystick.init()
joysticks = [pygame.joystick.Joystick(x) for x in range(pygame.joystick.get_count())]

pygame.init()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            break
        if event.type == pygame.JOYAXISMOTION:
            print(event)
    x_speed = round(pygame.joystick.Joystick(0).get_axis(0))
    y_speed = round(pygame.joystick.Joystick(0).get_axis(1))
    r_speed = round(pygame.joystick.Joystick(0).get_axis(2))
    v_speed = round(pygame.joystick.Joystick(0).get_axis(3))
    print("X-Speed " + str(x_speed) + "      Y-Speed " + str(y_speed) + "       R-Speed " + str(r_speed) + "       V-Speed " + str(v_speed))\
