import pygame

# library setup
pygame.joystick.init()
joysticks = [pygame.joystick.Joystick(x) for x in range(pygame.joystick.get_count())]

pygame.init()

# horizontal thrusters calculations
def calcHorizontal(joyValue, thrusterNum, direction):
    if (joyValue == 0):         # can adjust to create deadzone
        return 0
    # calculation for everything but 0
    return (((1/750) * ((abs(joyValue))**2.5)) * ((abs(joyValue))/(joyValue)) * direction[thrusterNum])

# vertical thrusters calculations
def calcVertical(joyValue, thrusterNum, direction):
    if (joyValue == 0):
        return 0
    # calculation for everything not 0
    return (((1/1000) * ((abs(joyValue))**2.5)) * ((abs(joyValue))/(joyValue)) * direction[thrusterNum])

# main loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            break
        if event.type == pygame.JOYAXISMOTION:
            print(event)
    # collect joystick values as -1 to 1
    x_speed = (pygame.joystick.Joystick(0).get_axis(0))
    y_speed = (pygame.joystick.Joystick(0).get_axis(1))
    r_speed = (pygame.joystick.Joystick(0).get_axis(2))
    v_speed = (pygame.joystick.Joystick(0).get_axis(3))
    #print("X-Speed " + str(x_speed) + "      Y-Speed " + str(y_speed) + "       R-Speed " + str(r_speed) + "       V-Speed " + str(v_speed))

    # ONLY USE IF ROTATION RANGE IS OFF
    # adjusting rotation range
    #r_speed += 0.5
    #if r_speed < 0:
        #r_speed = r_speed * 2
    #print(r_speed)

    # multiplies original values by 100 (necessary for calculations)
    x_speed = int(x_speed*100)
    y_speed = int(y_speed*100)
    r_speed = int(r_speed*100)
    v_speed = int(v_speed*100)
    # print("X-Speed " + str(x_speed) + "      Y-Speed " + str(y_speed) + "       R-Speed " + str(r_speed) + "       V-Speed " + str(v_speed))
    #print(r_speed)

    # each item in the list represents if the output for each thruster is pos. or neg.
    # ex: in xDirArray, the first element in index 0 (-1) expects that T1 would have a neg. output given a direction
    xDirArray = [-1, -1, 1, 1]
    yDirArray = [1, -1, 1, -1]
    rDirArray = [-1, 1, 1, -1]
    vDirArray = [-1, -1]

    # array for each horizontal thruster value
    thrusterVals = [0, 0, 0, 0]
    # array for each vertical thruster value
    vertThrusterVals = [0, 0]

    # loop to collect value for each thruster using horizontal calculation function
    for tNum in range(0,4):
        thrusterVals[tNum] = int((calcHorizontal(x_speed, tNum, xDirArray) + calcHorizontal(y_speed, tNum, yDirArray) + calcHorizontal(r_speed, tNum, rDirArray)))
        #print(thrusterVals[tNum])
    # loop to collect value for each thruster using vertical calculation function
    for vNum in range(0,2):
        vertThrusterVals[vNum] = int((calcVertical(v_speed, vNum, vDirArray)))

    max_thruster = 0
    for thrusters in range(0,4):
 #       max_thruster = thrusterVals[thrusters]
        max_thruster = max(max_thruster, abs(thrusterVals[thrusters]))
        #print(max_thruster)

 #   for thrusters in range(0, 4):
  #      if max_thruster == 0:
   #         thrusterVals[thrusters] = 0
    #    elif ma:
     #       thrusterVals[thrusters] = thrusters * (133 / max_thruster)

    if max_thruster != 0:
        for thrusters in range(0, 4):
            thrusterVals[thrusters] = int(thrusterVals[thrusters] * (100 / max_thruster))

    #print(max_thruster)

    # PRINT
    print(thrusterVals[0], " - ", thrusterVals[1], " - " , thrusterVals[2], " - ", thrusterVals[3], " - ", vertThrusterVals[0], " - ", vertThrusterVals[1])