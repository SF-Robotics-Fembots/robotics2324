import lgpio
import time
from adafruit_servokit import ServoKit
import board
import busio
import adafruit_pca9685

i2c = busio.I2C(board.SCL, board.SDA)
shield = adafruit_pca9685.PCA9685(i2c)
kit = ServoKit(channels = 16)
shield.frequency = 100
print("enter index:\n")
index = int(input(""))
thruster_channel = shield.channels[index]
thruster_channel.duty_cycle = 0x2666

print("enter pwm:\n")
throttle_in = int(input(""))

throttle_pw = int(throttle_in/10000*65536)
thruster_channel.duty_cycle = throttle_pw
time.sleep(1)

try:
	while 1:
		throttle_in = int(input(""))
		throttle_pw = int(throttle_in/10000*65536)
		print(throttle_pw)
		thruster_channel.duty_cycle = throttle_pw
		time.sleep(1)
		
except KeyboardInterrupt:
	throttle_in = 1500
	throttle_pw = int(throttle_in/10000*65536)
	thruster_channel.duty_cycle = throttle_pw
	time.sleep(1)
