import RPi.GPIO as GPIO
import socket


def main(ip_server):
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    GPIO.setup(23, GPIO.OUT)

    clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    clientSocket.connect((ip_server, 8181))

    while True:
        button = ((clientSocket.recv(1)).decode())
        #print(button)
        if (button == "a"):
            GPIO.output(23, GPIO.HIGH)
        if (button == "b"):
            GPIO.output(23, GPIO.LOW)

if __name__ == "__main__":
    main()
