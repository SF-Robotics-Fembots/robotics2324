import RPi.GPIO as GPIO
import time
import socket


def main(ip_server): 
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    GPIO.setup(5, GPIO.OUT)

    clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# 192.168.1.100 is comp computer ip
    clientSocket.connect((ip_server, 6060))

    while True:
        button = ((clientSocket.recv(1)).decode())
        #print(button)
        if (button == "a"):
            GPIO.output(5, GPIO.HIGH)
        if (button == "b"):
            GPIO.output(5, GPIO.LOW)

if __name__ == "__main__":
    main()
